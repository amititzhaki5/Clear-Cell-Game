package tests;

import static org.junit.Assert.*;

import java.util.Random;

import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;
import model.ClearCellGame;
import model.Game;
import model.BoardCell;

/* The following directive executes tests in sorted order */
@FixMethodOrder(MethodSorters.NAME_ASCENDING)

public class StudentTests {

	@Test
	public void testConstructor() {
		Random random = new Random();
		Game game = new ClearCellGame(4, 4, random, 1);
		System.out.println(getBoardStr(game));
	}

	@Test
	public void testGetMaxRows() {
		Random random = new Random();
		Game game1 = new ClearCellGame(4, 4, random, 1);
		int maxRows1 = game1.getMaxRows();

		Game game2 = new ClearCellGame(0, 0, random, 1);
		int maxRows2 = game2.getMaxRows();

		assertTrue(maxRows1 == 4);
		assertTrue(maxRows2 == 0);
	}

	@Test
	public void testGetMaxCols() {
		Random random = new Random();
		Game game1 = new ClearCellGame(4, 4, random, 1);
		int maxCols1 = game1.getMaxRows();

		Game game2 = new ClearCellGame(0, 0, random, 1);
		int maxCols2 = game2.getMaxRows();

		assertTrue(maxCols1 == 4);
		assertTrue(maxCols2 == 0);
	}

	@Test
	public void testSetGetBoardCell() {
		Random random = new Random();
		Game game1 = new ClearCellGame(4, 4, random, 1);

		game1.setBoardCell(1, 1, BoardCell.BLUE);
		BoardCell color = game1.getBoardCell(1, 1);
		BoardCell answer = BoardCell.BLUE;
		assertTrue(color == answer);

		game1.setBoardCell(2, 2, BoardCell.YELLOW);
		color = game1.getBoardCell(2, 2);
		answer = BoardCell.YELLOW;
		assertTrue(color == answer);
	}

	@Test
	public void testSetRowWithColor() {
		Random random = new Random();
		Game game1 = new ClearCellGame(4, 4, random, 1);
		game1.setRowWithColor(0, BoardCell.RED);
		String answer = getBoardStr(game1);
		System.out.print(answer);
		game1.setRowWithColor(0, BoardCell.YELLOW);
		answer = getBoardStr(game1);
		System.out.print(answer);
		game1.setRowWithColor(0, BoardCell.EMPTY);
		answer = getBoardStr(game1);
		System.out.print(answer);
	}

	@Test
	public void testSetColWithColor() {
		Random random = new Random();
		Game game1 = new ClearCellGame(4, 4, random, 1);
		game1.setColWithColor(0, BoardCell.BLUE);
		game1.setColWithColor(1, BoardCell.YELLOW);
		game1.setColWithColor(2, BoardCell.GREEN);
		game1.setColWithColor(3, BoardCell.RED);
		String answer = getBoardStr(game1);
		System.out.print(answer);

	}

	@Test
	public void testSetBoardWithColor() {
		Random random = new Random();
		Game game1 = new ClearCellGame(4, 4, random, 1);
		Game game2 = new ClearCellGame(4, 4, random, 1);
		Game game3 = new ClearCellGame(4, 4, random, 1);
		game1.setBoardWithColor(BoardCell.YELLOW);
		game2.setBoardWithColor(BoardCell.EMPTY);
		game3.setBoardWithColor(BoardCell.RED);
		String answer = getBoardStr(game1);
		answer += getBoardStr(game2);
		answer += getBoardStr(game3);
		System.out.print(answer);
	}

	@Test
	public void testIsGameOver() {
		Random random = new Random();
		Game game1 = new ClearCellGame(4, 4, random, 1);

		game1.setBoardCell(3, 3, BoardCell.BLUE);
		boolean over = game1.isGameOver();
		assertTrue(over == true);

		Game game2 = new ClearCellGame(4, 4, random, 1);
		game2.setBoardWithColor(BoardCell.EMPTY);
		over = game2.isGameOver();
		assertTrue(over == false);

	}

	@Test
	public void testGetScore() {
		Random random = new Random();
		Game game1 = new ClearCellGame(4, 4, random, 1);

		game1.setBoardWithColor(BoardCell.BLUE);
		game1.processCell(0, 0);
		int ans = game1.getScore();
		assertTrue(ans == 10);

		Game game2 = new ClearCellGame(4, 4, random, 1);
		game2.setBoardWithColor(BoardCell.BLUE);
		game2.setBoardCell(0, 0, BoardCell.YELLOW);
		game2.processCell(0, 0);
		ans = game2.getScore();
		assertTrue(ans == 1);
	}

	@Test
	public void testNextAnimationStep() {
		Random random1 = new Random();
		Game game1 = new ClearCellGame(6, 6, random1, 1);

		game1.setBoardWithColor(BoardCell.EMPTY);
		game1.nextAnimationStep();
		String ans = getBoardStr(game1);
		System.out.println(ans);

		game1.nextAnimationStep();
		ans = getBoardStr(game1);
		System.out.print(ans);

		Game game2 = new ClearCellGame(6, 6, random1, 1);
		game2.setBoardWithColor(BoardCell.YELLOW);
		ans = getBoardStr(game2);
		game2.nextAnimationStep();
		String str = getBoardStr(game2);
		assertTrue(ans.equals(str));

	}

	@Test
	public void testProcessCell() {
		Random random1 = new Random();
		Game game1 = new ClearCellGame(6, 6, random1, 1);
		game1.setBoardWithColor(BoardCell.BLUE);
		game1.processCell(2, 2);

		Random random2 = new Random();
		Game game2 = new ClearCellGame(6, 6, random2, 1);
		game2.setBoardWithColor(BoardCell.YELLOW);
		game2.setRowWithColor(0, BoardCell.RED);
		game2.setRowWithColor(3, BoardCell.BLUE);
		game2.setColWithColor(2, BoardCell.YELLOW);
		game2.processCell(2, 2);

		Random random3 = new Random();
		Game game3 = new ClearCellGame(6, 6, random3, 1);
		game3.setBoardWithColor(BoardCell.GREEN);
		game3.processCell(0, 0);

		Random random4 = new Random();
		Game game4 = new ClearCellGame(6, 6, random4, 1);
		game4.setBoardWithColor(BoardCell.BLUE);
		game4.setRowWithColor(1, BoardCell.GREEN);
		game4.setBoardCell(0, 0, BoardCell.GREEN);
		game4.setBoardCell(2, 2, BoardCell.GREEN);
		game4.setBoardCell(3, 3, BoardCell.GREEN);
		game4.setBoardCell(4, 4, BoardCell.GREEN);
		game4.setBoardCell(5, 5, BoardCell.GREEN);
		game4.setBoardCell(3, 5, BoardCell.GREEN);
		game4.processCell(1, 1);
	}

	@Test
	public void testDiagonal() {
		Random random5 = new Random();
		Game game5 = new ClearCellGame(9, 9, random5, 1);
		game5.setBoardWithColor(BoardCell.BLUE);
		game5.setRowWithColor(4, BoardCell.RED);
		game5.setBoardCell(3, 3, BoardCell.RED);
		game5.setBoardCell(2, 2, BoardCell.RED);
		game5.setBoardCell(1, 1, BoardCell.RED);
		game5.setBoardCell(3, 5, BoardCell.RED);
		game5.setBoardCell(2, 6, BoardCell.RED);
		game5.setBoardCell(1, 7, BoardCell.RED);
		game5.setBoardCell(0, 8, BoardCell.RED);
		game5.processCell(4, 4);

		System.out.print(getBoardStr(game5));
	}

	/* Support methods */
	private static String getBoardStr(Game game) {
		int maxRows = game.getMaxRows(), maxCols = game.getMaxCols();

		String answer = "Board(Rows: " + maxRows + ", Columns: " + maxCols + ")\n";
		for (int row = 0; row < maxRows; row++) {
			for (int col = 0; col < maxCols; col++) {
				answer += game.getBoardCell(row, col).getName();
			}
			answer += "\n";
		}

		return answer;
	}
}
